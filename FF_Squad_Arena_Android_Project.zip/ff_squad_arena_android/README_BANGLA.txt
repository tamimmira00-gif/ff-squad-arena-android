FF SQUAD ARENA — ANDROID APP PROJECT

এটি Android Studio-তে APK বানানোর জন্য তৈরি সোর্স প্রজেক্ট। এটি নিজে APK ফাইল নয়।

অ্যাপ চালু হলে আপনার বর্তমান ওয়েবসাইট খুলবে:
https://fanciful-sprite-50096f.netlify.app/

যা আছে:
- Android WebView অ্যাপ
- FF Squad Arena অ্যাপের নাম ও লোগো
- ইন্টারনেট পারমিশন
- JavaScript ও Local Storage সমর্থন
- Android Back বাটন দিয়ে আগের পেজে ফেরা
- বাইরের ওয়েবসাইট লিংক ব্রাউজারে খোলা

APK বানাতে:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. Android Studio খুলে এই ZIP extract করা FFSquadArena ফোল্ডারটি Open করুন।
3. Gradle Sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) চাপুন।
5. Build সফল হলে app/build/outputs/apk/debug/app-debug.apk পাওয়া যাবে।

গুরুত্বপূর্ণ:
- এই পরিবেশে Android SDK/Gradle build tools নেই, তাই এখানে APK compile করা হয়নি।
- এটি WebView wrapper; ওয়েবসাইটের ডেটা Supabase ও Netlify থেকেই আসবে।
- Release APK বিতরণের আগে Android Studio থেকে signed APK তৈরি করতে হবে।
